# Table Treegrid

Use Plugin: [bootstrap-table-treegrid](https://github.com/wenzhixin/bootstrap-table/tree/master/src/extensions/treegrid)

## Usage

```html
<script src="extensions/treegrid/bootstrap-table-treegrid.js"></script>
```

## Options

### treeShowField

* type: String
* description: 
* default: ``

### parentIdField

* type: String
* description: 
* default: `pid`
